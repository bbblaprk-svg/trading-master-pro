const {configured,command}=require('../lib/store');
module.exports=async function(req,res){
 res.setHeader('Cache-Control','no-store');
 if(req.method!=='POST')return res.status(405).json({error:'POST only'});
 if(!configured())return res.status(503).json({error:'server storage not configured'});
 const b=req.body||{},deviceId=String(b.deviceId||'');
 if(!/^[a-zA-Z0-9_-]{20,100}$/.test(deviceId))return res.status(400).json({error:'invalid deviceId'});
 const trades=Array.isArray(b.trades)?b.trades.filter(t=>t&&t.status==='holding').slice(0,30):[];
 let previous={};
 try{const raw=await command(['GET',`trading:device:${deviceId}`]);if(raw)previous=JSON.parse(raw)}catch(_){previous={}}
 const record={...previous,deviceId,enabled:b.enabled!==false,trades,subscription:b.subscription||previous.subscription||null,alertState:previous.alertState||{},lastCheckedAt:previous.lastCheckedAt||null,lastError:previous.lastError||'',updatedAt:new Date().toISOString()};
 await command(['SET',`trading:device:${deviceId}`,JSON.stringify(record)]);
 await command(['SADD','trading:devices',deviceId]);
 return res.status(200).json({ok:true,count:trades.length,backgroundReady:Boolean(record.subscription&&record.enabled),preservedState:true});
};
