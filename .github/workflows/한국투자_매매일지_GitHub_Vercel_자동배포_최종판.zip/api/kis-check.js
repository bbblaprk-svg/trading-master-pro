const { configured, getAccessToken } = require('../lib/kis');
module.exports = async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (!configured()) return res.status(200).json({ ok: false, configured: false, message: 'KIS 환경변수가 없습니다.' });
  try {
    await getAccessToken();
    return res.status(200).json({ ok: true, configured: true, environment: process.env.KIS_ENV === 'virtual' ? 'virtual' : 'real', message: '한국투자 인증 성공' });
  } catch (e) {
    return res.status(200).json({ ok: false, configured: true, message: e.message || '한국투자 인증 실패' });
  }
};
