module.exports = async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  const configured = Boolean(process.env.KIS_BRIDGE_URL && process.env.KIS_BRIDGE_TOKEN);
  res.status(200).json({
    mobileOnly: true,
    krxReference: true,
    nxtRealtime: configured,
    integratedRealtime: configured,
    message: configured ? '클라우드 실시간 시세 연결 완료' : 'NXT 실시간용 클라우드 API 설정이 필요합니다.'
  });
};
