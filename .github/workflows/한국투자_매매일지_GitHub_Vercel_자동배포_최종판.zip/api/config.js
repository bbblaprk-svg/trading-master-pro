const { configured } = require('../lib/kis');
module.exports = async function handler(req,res){
  res.setHeader('Cache-Control','no-store');
  const kis=configured();
  const bridge=Boolean(process.env.KIS_BRIDGE_URL&&process.env.KIS_BRIDGE_TOKEN);
  res.status(200).json({krx:kis,nxt:bridge,integrated:bridge,mode:bridge?'kis-real-integrated':kis?'kis-real-rest':'not-configured',environment:process.env.KIS_ENV==='virtual'?'모의투자':'실전투자',message:bridge?'한국투자 KRX·NXT 통합 연결 준비 완료':kis?'한국투자 KRX 실전 현재가 연결 준비 완료':'Vercel 환경변수에 KIS_APP_KEY와 KIS_APP_SECRET을 등록하세요.'});
};
