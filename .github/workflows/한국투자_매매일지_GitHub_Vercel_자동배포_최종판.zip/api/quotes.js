const { configured, getAccessToken, getQuote } = require('../lib/kis');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

async function getBridgeQuotes(codes) {
  const base = String(process.env.KIS_BRIDGE_URL || '').replace(/\/$/, '');
  const token = process.env.KIS_BRIDGE_TOKEN || '';
  if (!base || !token || !codes.length) return new Map();
  const r = await fetch(base + '/quotes?codes=' + encodeURIComponent(codes.join(',')), {
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' }
  });
  if (!r.ok) throw new Error(`NXT 브리지 응답 오류(${r.status})`);
  const d = await r.json();
  return new Map((d.quotes || []).map(q => [String(q.code), q]));
}

module.exports = async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.setHeader('Access-Control-Allow-Origin', '*');
  const raw = String((req.query && req.query.symbols) || '');
  const symbols = [...new Set(raw.split(',').map(s => s.trim().toUpperCase()).filter(s => /^\d{6}\.(KS|KQ)$/.test(s)))].slice(0, 30);
  if (!symbols.length) return res.status(400).json({ error: 'symbols parameter required', quotes: [] });
  if (!configured()) return res.status(503).json({ error: '한국투자 실전 API 환경변수가 설정되지 않았습니다.', required: ['KIS_APP_KEY','KIS_APP_SECRET','KIS_ENV'], quotes: [] });

  try {
    const token = await getAccessToken();
    let bridge = new Map();
    let bridgeError = '';
    try { bridge = await getBridgeQuotes(symbols.map(s => s.slice(0,6))); } catch (e) { bridgeError = e.message || String(e); }
    const quotes = [];
    for (let i = 0; i < symbols.length; i += 5) {
      const rows = await Promise.all(symbols.slice(i, i + 5).map(async symbol => {
        try {
          const code = symbol.slice(0,6);
          const q = await getQuote(code, token);
          const b = bridge.get(code) || {};
          const nxtPrice = Number(b.nxtPrice || 0);
          const integratedPrice = Number(b.integratedPrice || nxtPrice || q.price);
          return { symbol, krxPrice:q.price, nxtPrice, integratedPrice, price:integratedPrice, open:q.open, high:Math.max(q.high, integratedPrice), low:q.low, changeRate:q.changeRate, source:nxtPrice?'한국투자 KRX·NXT 통합':'한국투자 실전 현재가', tradeTime:q.tradeTime, time:b.updatedAt||q.time, receivedAt:new Date().toISOString() };
        } catch (e) { return { symbol, error:e.message || 'quote unavailable' }; }
      }));
      quotes.push(...rows);
      if (i + 5 < symbols.length) await sleep(350);
    }
    return res.status(200).json({ fetchedAt:new Date().toISOString(), mode:bridge.size?'kis-real-integrated':'kis-real-rest', bridgeError, quotes });
  } catch (e) { return res.status(502).json({ error:e.message || '한국투자 API 연결 실패', quotes:[] }); }
};
