module.exports=async function(req,res){
 res.setHeader('Cache-Control','no-store');
 const storage=Boolean(process.env.UPSTASH_REDIS_REST_URL&&process.env.UPSTASH_REDIS_REST_TOKEN);
 const vapid=Boolean(process.env.VAPID_PUBLIC_KEY&&process.env.VAPID_PRIVATE_KEY);
 const quoteSource=Boolean(process.env.KIS_BRIDGE_URL&&process.env.KIS_BRIDGE_TOKEN);
 const cronSecret=Boolean(process.env.CRON_SECRET);
 res.status(200).json({ok:true,storage,vapid,quoteSource,cronSecret,backgroundReady:storage&&vapid});
};
