매매일지 한국투자 실시간 연동 최종 수정판

1. 이 ZIP 파일을 압축 해제하지 않고 Vercel의 새 프로젝트에 업로드합니다.
2. Vercel 프로젝트 Settings > Environment Variables에 아래 3개를 등록합니다.
   KIS_APP_KEY = 한국투자 실전 App Key
   KIS_APP_SECRET = 한국투자 실전 App Secret
   KIS_ENV = real
3. Redeploy 후 프로젝트 화면의 Visit 버튼을 누릅니다.
4. 앱에서 종목 검색 결과를 눌러 종목코드를 선택하고 저장합니다.
5. 대시보드의 현재가 새로고침을 누르면 즉시 조회되며, 화면이 열려 있는 동안 1분마다 자동 갱신됩니다.

NXT 안내
- KRX 현재가는 Vercel만으로 동작합니다.
- NXT 실시간은 지속적인 WebSocket 연결이 필요하여 cloud-bridge 폴더를 상시 실행 서버에 별도 배포해야 합니다.
- 브리지 배포 후 Vercel에 KIS_BRIDGE_URL, KIS_BRIDGE_TOKEN을 추가하면 NXT/통합 현재가가 활성화됩니다.
- 브리지를 설정하지 않은 경우 NXT 칸은 '미연결'로 표시되며 KRX 현재가로 정상 작동합니다.

중요
- App Key와 Secret은 index.html 또는 아이폰에 저장되지 않습니다.
- 앱을 완전히 종료한 뒤의 푸시 감시는 Redis/VAPID/Cron 설정이 추가로 필요합니다.
