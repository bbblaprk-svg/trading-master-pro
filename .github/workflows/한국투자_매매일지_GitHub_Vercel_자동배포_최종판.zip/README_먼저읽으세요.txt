아이폰 매매일지 · NXT 실시간 시세 연동형

이 버전은 다음 구조입니다.
아이폰 앱 → Vercel → 클라우드 브리지 → 한국투자 Open API 실시간 시세
주문은 계속 대신증권 CYBOS Touch에서 합니다.

중요:
- APP Key가 없는 상태에서는 NXT 실시간 가격이 나오지 않습니다.
- 먼저 한국투자증권 계좌를 개설하고 Open API를 신청해야 합니다.
- 키를 발급받으면 cloud-bridge를 Railway/Render에 배포하고,
  Vercel에 KIS_BRIDGE_URL 및 KIS_BRIDGE_TOKEN을 등록합니다.
- 보안키는 HTML이나 아이폰에 직접 넣지 마십시오.

포함 기능:
- 기존 매매일지 기능 유지
- KRX/NXT/통합 현재가 칸
- 최고가 자동 갱신
- 평가손익·수익률·수정손절가 자동 계산
- 순차 익절 수량 안내
- NXT 클라우드 브리지 코드
- Docker 배포 파일
