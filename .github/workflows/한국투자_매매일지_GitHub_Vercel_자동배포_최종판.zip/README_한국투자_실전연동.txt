[한국투자 실전 현재가 연동 순서]

1. 이 ZIP 파일을 Vercel의 "Drop It. It's Live." 화면에서 ZIP 그대로 선택해 배포합니다.
2. 배포가 끝나면 Vercel Dashboard에서 해당 프로젝트를 선택합니다.
3. Settings > Environment Variables로 이동합니다.
4. 아래 3개를 Production에 각각 등록합니다.

   KIS_APP_KEY       = 발급받은 실전 App Key
   KIS_APP_SECRET    = 발급받은 실전 App Secret
   KIS_ENV           = real

5. Deployments > 최신 배포 오른쪽 메뉴 > Redeploy를 실행합니다.
6. 배포 주소 뒤에 /api/kis-check 를 붙여 열어 봅니다.
   예: https://프로젝트주소.vercel.app/api/kis-check
7. "ok":true, "한국투자 인증 성공"이 나오면 연동 완료입니다.
8. 매매일지에서 6자리 종목코드를 입력하고 현재가 새로고침을 누릅니다.

주의
- App Key와 App Secret을 HTML 입력란, 메모, 채팅에 넣지 마십시오.
- 현재 버전은 조회 전용이며 주문 기능을 수행하지 않습니다.
- REST 방식이므로 체결 스트리밍(WebSocket)은 아니지만, 기존 20분 지연 참고시세를 사용하지 않습니다.
- 계좌번호는 현재가 조회에 필요하지 않습니다.
