# 아이폰 매매일지용 KIS NXT 실시간 브리지

이 서버는 주문을 하지 않고 KRX/NXT/통합 실시간 시세만 전달합니다.
거래는 계속 대신증권 CYBOS Touch에서 하시면 됩니다.

## 필요한 것
1. 한국투자증권 계좌
2. KIS Developers Open API 신청
3. APP Key / APP Secret
4. Railway, Render 등 지속 실행 가능한 서버

## 배포
- 이 cloud-bridge 폴더를 GitHub 저장소에 올립니다.
- Railway 또는 Render에서 Docker 서비스로 배포합니다.
- .env.example 항목을 환경변수로 등록합니다.
- 발급한 키는 HTML, 채팅, 공개 저장소에 넣지 마십시오.

## 앱(Vercel) 환경변수
KIS_BRIDGE_URL=https://배포된-브리지-주소
KIS_BRIDGE_TOKEN=BRIDGE_TOKEN과 같은 값

## 중요
한국투자 API의 TR ID와 응답 필드 순서는 공식 API 문서에서 확인해 환경변수에 넣도록 구성했습니다.
API 사양 변경 시 서버 코드를 다시 만들지 않고 환경변수만 수정할 수 있습니다.
