'use strict';
const express = require('express');
const cors = require('cors');
const WebSocket = require('ws');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = Number(process.env.PORT || 3000);
const APP_KEY = process.env.KIS_APP_KEY || '';
const APP_SECRET = process.env.KIS_APP_SECRET || '';
const BRIDGE_TOKEN = process.env.BRIDGE_TOKEN || '';
const WS_URL = process.env.KIS_WS_URL || 'ws://ops.koreainvestment.com:21000';
// 한국투자 API 문서에서 확인한 TR ID를 환경변수로 넣도록 구성했습니다.
const TR_ID_NXT = process.env.KIS_TR_ID_NXT || '';
const TR_ID_INTEGRATED = process.env.KIS_TR_ID_INTEGRATED || '';
const codes = new Set((process.env.WATCH_CODES || '').split(',').map(v=>v.trim()).filter(v=>/^\d{6}$/.test(v)));
const quotes = new Map();
let ws = null;
let approvalKey = '';
let connected = false;
let lastError = '';

function auth(req,res,next){
  if (!BRIDGE_TOKEN) return res.status(503).json({error:'BRIDGE_TOKEN not configured'});
  const token = String(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
  if(token !== BRIDGE_TOKEN) return res.status(401).json({error:'unauthorized'});
  next();
}

async function issueApprovalKey(){
  if(!APP_KEY || !APP_SECRET) throw new Error('KIS_APP_KEY / KIS_APP_SECRET not configured');
  const r = await fetch('https://openapi.koreainvestment.com:9443/oauth2/Approval',{
    method:'POST', headers:{'content-type':'application/json'},
    body:JSON.stringify({grant_type:'client_credentials',appkey:APP_KEY,secretkey:APP_SECRET})
  });
  if(!r.ok) throw new Error('approval key HTTP '+r.status);
  const j = await r.json();
  if(!j.approval_key) throw new Error(j.msg1 || 'approval_key missing');
  approvalKey = j.approval_key;
}

function subscribe(code,trId){
  if(!ws || ws.readyState!==WebSocket.OPEN || !trId) return;
  ws.send(JSON.stringify({header:{approval_key:approvalKey,custtype:'P',tr_type:'1','content-type':'utf-8'},body:{input:{tr_id:trId,tr_key:code}}}));
}

function parseTick(text){
  // KIS 실시간 응답은 일반적으로 0|TR_ID|건수|구분자 데이터 형식입니다.
  if(!text.startsWith('0|')) return;
  const parts=text.split('|');
  if(parts.length<4) return;
  const trId=parts[1];
  const rows=parts.slice(3).join('|').split('^');
  // 체결가 데이터의 종목코드/체결시간/현재가는 API 변경 가능성이 있어
  // 환경변수로 인덱스를 조정할 수 있게 했습니다.
  const codeIdx=Number(process.env.KIS_FIELD_CODE_INDEX ?? 0);
  const timeIdx=Number(process.env.KIS_FIELD_TIME_INDEX ?? 1);
  const priceIdx=Number(process.env.KIS_FIELD_PRICE_INDEX ?? 2);
  const code=String(rows[codeIdx]||'').replace(/\D/g,'').slice(-6);
  const price=Number(String(rows[priceIdx]||'').replace(/,/g,''));
  if(!/^\d{6}$/.test(code)||!Number.isFinite(price)||price<=0) return;
  const old=quotes.get(code)||{code,krxPrice:0,nxtPrice:0,integratedPrice:0};
  if(trId===TR_ID_NXT) old.nxtPrice=price;
  if(trId===TR_ID_INTEGRATED) old.integratedPrice=price;
  if(!old.integratedPrice) old.integratedPrice=old.nxtPrice||old.krxPrice;
  old.time=String(rows[timeIdx]||new Date().toISOString());
  old.updatedAt=new Date().toISOString();
  quotes.set(code,old);
}

async function connect(){
  try{
    if(!TR_ID_NXT && !TR_ID_INTEGRATED) throw new Error('KIS_TR_ID_NXT 또는 KIS_TR_ID_INTEGRATED 설정 필요');
    await issueApprovalKey();
    ws=new WebSocket(WS_URL);
    ws.on('open',()=>{connected=true;lastError='';for(const code of codes){subscribe(code,TR_ID_NXT);subscribe(code,TR_ID_INTEGRATED);}});
    ws.on('message',buf=>{const text=buf.toString();if(text.startsWith('{')){try{const j=JSON.parse(text);if(j.header?.tr_id==='PINGPONG')ws.send(text);}catch(_){}}else parseTick(text);});
    ws.on('close',()=>{connected=false;setTimeout(connect,5000);});
    ws.on('error',e=>{connected=false;lastError=e.message;});
  }catch(e){connected=false;lastError=e.message;setTimeout(connect,10000);}
}

app.get('/health',(req,res)=>res.json({ok:true,connected,lastError,watchCount:codes.size,quoteCount:quotes.size}));
app.post('/watch',auth,(req,res)=>{const list=Array.isArray(req.body.codes)?req.body.codes:[];for(const raw of list){const code=String(raw).replace(/\D/g,'').slice(0,6);if(/^\d{6}$/.test(code)&&!codes.has(code)){codes.add(code);subscribe(code,TR_ID_NXT);subscribe(code,TR_ID_INTEGRATED);}}res.json({ok:true,codes:[...codes]});});
app.get('/quotes',auth,(req,res)=>{const requested=String(req.query.codes||'').split(',').map(v=>v.trim()).filter(v=>/^\d{6}$/.test(v));for(const c of requested){if(!codes.has(c)){codes.add(c);subscribe(c,TR_ID_NXT);subscribe(c,TR_ID_INTEGRATED);}}res.json({connected,quotes:requested.map(c=>quotes.get(c)||{code:c,krxPrice:0,nxtPrice:0,integratedPrice:0,error:'아직 체결 수신 전'}),time:new Date().toISOString()});});

app.listen(PORT,()=>{console.log('KIS NXT bridge listening on',PORT);connect();});
