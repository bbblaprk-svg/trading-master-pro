# 한국투자 실시간 매매일지

아이폰 Safari와 Vercel에서 사용하는 매매일지 PWA입니다. 한국투자증권 실전 REST API를 통해 KRX 현재가를 조회하며, 별도 NXT 브리지를 연결하면 NXT 및 통합 현재가를 표시합니다.

## 주요 기능

- 보유종목 최대 30개 관리
- 한국투자 KRX 현재가 조회 및 1분 자동 갱신
- 최고가 갱신과 단계별 수익보호·추세추종 손절가 계산
- 손절·익절 조건 알림
- Safari 홈 화면 설치(PWA)
- 선택형 NXT 브리지 연동

## GitHub에서 Vercel로 배포

1. GitHub에서 새 저장소를 만듭니다.
2. 이 ZIP의 압축을 풀고 **폴더 안의 파일 전체**를 저장소 최상단에 업로드합니다.
3. Vercel에서 `Add New > Project`를 누르고 해당 GitHub 저장소를 선택합니다.
4. Framework Preset은 `Other`, Root Directory는 `./`로 둡니다.
5. Vercel 환경변수에 다음 값을 등록합니다.

```text
KIS_APP_KEY=한국투자 실전 App Key
KIS_APP_SECRET=한국투자 실전 App Secret
KIS_ENV=real
```

6. Deploy를 누른 뒤 생성된 `https://프로젝트명.vercel.app` 주소를 엽니다.
7. 아이폰 Safari의 공유 버튼에서 `홈 화면에 추가`를 선택합니다.

## NXT 연동(선택)

NXT는 별도 상시 실행 브리지가 필요합니다. 브리지를 배포한 뒤 Vercel 환경변수에 다음을 추가합니다.

```text
KIS_BRIDGE_URL=https://브리지주소
KIS_BRIDGE_TOKEN=충분히_긴_임의의_토큰
```

브리지가 없을 때 앱은 한국투자 KRX 현재가를 정상적으로 사용하고 NXT는 미연결로 표시합니다.

## 보안

- App Key와 App Secret은 GitHub 파일에 절대 입력하지 마십시오.
- 비밀값은 Vercel의 Environment Variables에만 저장하십시오.
- `.env` 파일은 `.gitignore`에 포함되어 있습니다.

## 상태 확인

배포 후 다음 주소에서 서버 상태를 확인할 수 있습니다.

- `/api/status`
- `/api/config`
- `/api/kis-check`

자세한 순서는 `GITHUB_VERCEL_배포안내.txt`를 참고하십시오.
