[중요] 백그라운드 감시는 HTML만으로는 작동하지 않습니다.
이 ZIP에는 서버 동기화·Web Push·1분 감시 API가 포함되어 있습니다.

1. Vercel에 이 ZIP을 배포합니다.
2. Upstash에서 무료 Redis 데이터베이스를 만들고 Vercel Environment Variables에 아래를 넣습니다.
   UPSTASH_REDIS_REST_URL
   UPSTASH_REDIS_REST_TOKEN
3. PC에서 ZIP을 풀고 터미널에서 다음을 실행해 Web Push 키를 만듭니다.
   npm install
   npm run generate-vapid
   출력된 publicKey/privateKey를 Vercel 환경변수에 등록합니다.
   VAPID_PUBLIC_KEY
   VAPID_PRIVATE_KEY
   VAPID_SUBJECT=mailto:bbblaprk@gmail.com
4. CRON_SECRET에 임의의 16자 이상 비밀번호를 등록합니다.
5. Vercel Hobby는 Cron을 하루 1회만 허용하므로, cron-job.org 또는 UptimeRobot 같은 외부 스케줄러에서 다음 주소를 1분마다 호출합니다.
   https://본인주소.vercel.app/api/cron-monitor?secret=CRON_SECRET값
   Vercel Pro 이상은 vercel.json의 crons 항목으로 1분 호출을 설정할 수 있습니다.
6. Vercel에서 Redeploy 합니다.
7. 아이폰 Safari로 Visit 주소를 열고 공유 → 홈 화면에 추가합니다.
8. 홈 화면의 매매일지 앱을 열어 '전체 감시 켜기' → '백그라운드 감시 등록'을 누르고 알림을 허용합니다.

동작 범위
- 앱 화면이 열려 있을 때: 기존 1분 자동조회·소리·화면 알림
- 화면 잠금/다른 앱/앱 종료: 서버가 조회하고 Web Push 전송
- 보유종목 저장·수정·삭제: 서버에 자동 동기화
- 1분 감시 정확도는 시세 제공 서버와 외부 스케줄러 실행 주기에 좌우됩니다.
