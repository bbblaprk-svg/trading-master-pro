매매일지 100점형: KRX/NXT 통합시세 준비 버전

[현재 즉시 작동]
- 기존 매매일지 전체 기능
- KRX 참고 현재가 자동 갱신
- 평가손익/수익률/최고가/수정손절가 자동 계산
- 대시보드 KRX/NXT/통합현재가 분리 표시
- NXT 미연결 상태 명확 표시

[NXT 실시간을 켜려면 반드시 필요한 것]
- 한국투자증권 Open API 신청 후 App Key/App Secret/HTS ID 발급
- KIS WebSocket을 계속 실행할 별도 브리지 서버
- Vercel 환경변수 KIS_BRIDGE_URL, KIS_BRIDGE_TOKEN 설정

중요: Vercel의 짧게 실행되는 서버리스 함수만으로는 지속적인 WebSocket 연결을 안정적으로 유지하기 어렵습니다. 따라서 NXT 실시간은 별도의 상시 실행 브리지가 필요합니다.

보안: App Secret은 HTML, ZIP 공개파일, 아이폰 로컬스토리지에 절대 입력하지 마십시오.
