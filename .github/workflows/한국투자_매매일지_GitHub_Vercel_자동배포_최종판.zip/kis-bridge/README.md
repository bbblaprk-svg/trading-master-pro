# KIS NXT 실시간 브리지

이 폴더는 한국투자증권 Open API WebSocket의 KRX·NXT·통합 실시간 체결가를 받아 웹앱에 전달하는 **연결 지점**입니다.

## 필요한 것
1. 한국투자증권 계좌 및 Open API 신청
2. App Key, App Secret, HTS ID
3. 24시간 실행 가능한 Node/Python 서버(Render, Railway, 개인 PC 등)
4. 공식 KIS 샘플의 국내주식 실시간체결가 KRX/NXT/통합 구독 함수 연결

## 보안 원칙
- App Secret을 index.html이나 iPhone에 저장하지 마십시오.
- 브리지 서버 환경변수에만 저장하십시오.
- 웹앱의 Vercel 환경변수에는 `KIS_BRIDGE_URL`, `KIS_BRIDGE_TOKEN`만 입력하십시오.

## 웹앱이 기대하는 응답
`GET /quotes?codes=005930,000660`

```json
{
  "quotes": [
    {"code":"005930","krxPrice":90000,"nxtPrice":90100,"integratedPrice":90100,"time":"2026-07-12T10:00:00+09:00"}
  ]
}
```

브리지는 공식 KIS 문서의 WebSocket 구독키와 필드 배열이 변경될 수 있으므로, 발급받은 계정의 최신 공식 샘플코드에 맞춰 연결해야 합니다.
